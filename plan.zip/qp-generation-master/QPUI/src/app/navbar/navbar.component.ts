import { Component, OnInit } from '@angular/core';

import { Router } from "@angular/router";
import { log } from 'util';
@Component({
  selector: 'app-navbar',
  moduleId: module.id,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

agree: boolean = false;
bookOptionSelected: boolean = false;
//agree: boolean = false;
dable: boolean = false;
visible:boolean;
  constructor(private router: Router) {
  
    
   }

  ngOnInit() {
   
  }




logout:boolean=true;
login:boolean=true;

click(){
  this.login=false;
  this.router.navigate(['/login']);
}

clickout(){
 sessionStorage.setItem('isLoggedIn', 'false');
//  console.log(isLoggedIn);
 
 sessionStorage.removeItem('token');
 sessionStorage.removeItem('designation');
 this.logout=false;
 
 this.router.navigate(['/login']);
}
login_enable(){
 
 if(sessionStorage.getItem('isLoggedIn') == "false"){
   return true;
 }
 return false;
}

logout_enable(){

 if(sessionStorage.getItem('isLoggedIn') == "true"){
   return true;
 }
 else{
 return false;
 }
}
admin()
{
 if(sessionStorage.getItem('designation') == "Admin"){
  return true;

}
}
user()
{
 if(sessionStorage.getItem('designation') == "User"){
  return true;

}
}

}
