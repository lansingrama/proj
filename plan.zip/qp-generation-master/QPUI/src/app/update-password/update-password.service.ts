import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable()
export class UpdateService{
    url="http://localhost:1050/update"
    constructor(private http:HttpClient){}
    update(data:any,username:any):Observable<any>{
        
        data.userName=username;
       
        return this.http.post<any>(this.url,data);
    }
}