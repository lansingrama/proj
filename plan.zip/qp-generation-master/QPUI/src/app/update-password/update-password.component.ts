import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateService } from './update-password.service';
import { DISABLED } from '../../../node_modules/@angular/forms/src/model';


@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css'],
  providers:[UpdateService]
})
export class UpdatePasswordComponent implements OnInit {
  UpdateForm: FormGroup;

  successmessage: string;
  errormessage: string;
  returnUrl: string;
  username:string;

  constructor(private router: Router, private UpdateService: UpdateService, private formBuilder: FormBuilder)  { }

  ngOnInit() {
    this.username=sessionStorage.getItem('token')
    
    this.UpdateForm = this.formBuilder.group({
      uname: ['', [ Validators.pattern(/^[A-Za-z0-9_]+$/)]],
      oldPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required,Validators.minLength(6),Validators.maxLength(6)]]
      



    })
    
  }
  get f() { return this.UpdateForm.controls; }
  onFormSubmit() {

    if (this.UpdateForm.invalid) {
      return;
    }
    else {
      this.successmessage = ""
      this.errormessage = ""
      this.UpdateService.update(this.UpdateForm.value,this.username).subscribe(
        (good) => {
          
            this.successmessage = good.message
            
        },
        (bad) => {
          
          this.errormessage = bad.error.message
        }
      );
    }

  }
  variable()
  {
    if(sessionStorage.getItem('isLoggedIn') == "true"){
      return true;
    }
  }
}
