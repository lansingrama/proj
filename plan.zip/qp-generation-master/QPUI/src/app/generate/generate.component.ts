import { Component, OnInit } from '@angular/core';
import { generateService } from './generate.service';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-generate',
  templateUrl: './generate.component.html',
  styleUrls: ['./generate.component.css']
})
export class GenerateComponent implements OnInit {

  constructor(private service: generateService, private formBuilder: FormBuilder) { }
  domainObj: any;
  GForm: FormGroup;
  Successmessage: String;
  errorMsg: String;
  ngOnInit() {
    this.errorMsg = null;
    this.domainObj = null;
    this.GForm = this.formBuilder.group({
      batchname: ['', [Validators.required, Validators.pattern(/^[A-Za-z]{3}(-)[0-9]{2}$/)]],
      fa: ['', [Validators.required]]
    })

  }
  generateqp(batchname,fa) {
    // console.log("domain"+domain)
    // console.log("final"+this.final)
    this.service.generateqp(batchname,fa).subscribe((response) => {
      this.domainObj = response;
     

    }, (err) => { this.errorMsg = err.error.message; })
  }

  generateqp1(batchname,fa) {
    // console.log("domain"+domain)
    // console.log("final"+this.final)
    this.service.generateqp1(batchname,fa).subscribe((response) => {
      this.Successmessage = response;
     

    }, (err) => { this.errorMsg = err.error.message; })
  }


}
