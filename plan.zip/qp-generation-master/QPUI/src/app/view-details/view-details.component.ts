import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule , FormGroup} from '@angular/forms';
import { Service } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [Service]
})
export class ViewDetailsComponent implements OnInit {

  flightDetails: FlightBooking[];
  successMessage: String;
  errorMessage: String;
  QpForm: FormGroup;
  FA:String

// Add neccessary dependencies
  constructor(private formBuilder:FormBuilder) { }

  

  ngOnInit() {
    // this.view();
    this.QpForm = this.formBuilder.group({
      qpid: ['',[Validators.required,Validators.pattern(/^(QP-)[0-9]{3}$/)]],
      gitlink: ['',[Validators.required]],
      Domain: ['',[Validators.required,Validators.pattern(/^[A-Za-z0-9_]+$/)]],
      Author: ['',[Validators.required,Validators.pattern(/^[A-Za-z0-9_]+$/)]],
      FA: ['FA1',[Validators.required]],

    });
  }

  view() {
    //Your code goes here
  }

  delete(bookingId) {
    //Your code goes here
  }
}

