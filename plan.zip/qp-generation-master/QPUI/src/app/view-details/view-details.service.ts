import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
//import { AccessGuard } from '../gaurdservice';

@Injectable()
export class Service {

 //add neccessary dependencies\
 canLoginToday(): boolean {
  let today = new Date();
  if(today.getDay()==6 || today.getDay()==5) {
      return false; // weekends
  }
  else return true;
}

  constructor() {
   
  }
  
    
 
}
