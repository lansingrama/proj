import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
//import { AccessGuard } from '../gaurdservice';

@Injectable()
export class ExportService {

 //add neccessary dependencies\
 

  constructor(public http: HttpClient) {
   
  }
  export() : Observable<any> {
      
    return <Observable<any>> this.http.get(`http://localhost:1050/export`);
  }
  
    
 
}
