import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// import { ViewDetailsComponent } from './view-details/view-details.component','./view-details/gaurdService';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { LoginComponent } from './login/login.component';
import { LedgerComponent } from './ledger/ledger.component';
import { AuthGuard } from './auth.gaurd';
import { NavbarComponent } from './navbar/navbar.component';
import { UpdatePasswordComponent } from './update-password/update-password.component'
import { HomeComponent } from './home/home.component';
import { MailerTemplateComponent } from './mailer-template/mailer-template.component';
import { ViewDomainComponent } from './view-domain/view-domain.component';
import { UpdateQpComponent } from './update-qp/update-qp.component';
import { ViewLogsComponent } from './view-logs/view-logs.component';
import { PastArtifactsComponent } from './past-artifacts/past-artifacts.component';
import { ExportComponent } from './export/export.component';
import { GenerateComponent } from './generate/generate.component';
//import {AuthGuard} from './gaurdservice';



export const routes: Routes = [
  //Add logic for routes
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'navbar', component: NavbarComponent, canActivate: [AuthGuard] },
  { path: 'past', component: PastArtifactsComponent, canActivate: [AuthGuard] },
  { path: 'view', component: ViewDetailsComponent, canActivate: [AuthGuard] },
  { path: 'view-domain', component: ViewDomainComponent, canActivate: [AuthGuard] },
  { path: 'view-logs', component: ViewLogsComponent, canActivate: [AuthGuard] },
  { path: 'ledger', component: LedgerComponent, canActivate: [AuthGuard] },
  { path: 'export', component: ExportComponent, canActivate: [AuthGuard] },
  { path: 'update', component: UpdatePasswordComponent, canActivate: [AuthGuard] },
  { path: 'update-qp', component: UpdateQpComponent, canActivate: [AuthGuard] },
  { path: 'mail', component: MailerTemplateComponent, canActivate: [AuthGuard] },
  { path: 'generate', component: GenerateComponent, canActivate: [AuthGuard] },



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
