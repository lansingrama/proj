import { Component, OnInit } from '@angular/core';
import { ViewLogService } from './view-logs.service';

@Component({
  selector: 'app-view-logs',
  templateUrl: './view-logs.component.html',
  styleUrls: ['./view-logs.component.css']
})
export class ViewLogsComponent implements OnInit {

  constructor(public service:ViewLogService) { }
  domainObj: any;
  errorMsg: String;
  detailsObj: String;
  element: String;
  token:String;
  ngOnInit() {
    this.errorMsg = null;
    this.domainObj = null;
    this.service.viewlogs().subscribe((response) => {
      this.domainObj = response;
    //  this.token=sessionStorage.getItem('token')

      
    }, (err) => { this.errorMsg = err.error.message; })
    
  }

}
