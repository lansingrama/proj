import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from "@angular/common/http";
import { ViewDetailsComponent } from './view-details/view-details.component';

import { AuthGuard} from './auth.gaurd';
import { LoginComponent } from './login/login.component';
import { LedgerComponent } from './ledger/ledger.component';
import { Service } from './view-details/view-details.service';

import { NavbarComponent } from './navbar/navbar.component';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { HomeComponent } from './home/home.component';
import { MailerTemplateComponent } from './mailer-template/mailer-template.component';
import { ViewDomainComponent } from './view-domain/view-domain.component';
import { UpdateQpComponent } from './update-qp/update-qp.component';
import { ViewLogsComponent } from './view-logs/view-logs.component';
import { PastArtifactsComponent } from './past-artifacts/past-artifacts.component';
import { ExportComponent } from './export/export.component';
import { ViewDomainService } from './view-domain/view-domain.service';
import { ExportService } from './export/export.service';
import { ViewLogService } from './view-logs/view-logs.service';
import { PastArtifactsService } from './past-artifacts/past-artifacts.service';
//import { UpdatePasswordComponent } from './update-password/update-password.component';
//import { UpdateService } from './update-password/update-password.service';

import {Ng2PaginationModule} from 'ng2-pagination';
import { GenerateComponent } from './generate/generate.component';
import { generateService } from './generate/generate.service';
import { updateqpService } from './update-qp/update-qp.service';
import { ledgerService } from './ledger/ledger.service';

@NgModule({
  declarations: [
    AppComponent,
   
    ViewDetailsComponent,
   
    
    LoginComponent,
    LedgerComponent,
    NavbarComponent,
    UpdatePasswordComponent,
    HomeComponent,
    MailerTemplateComponent,
    ViewDomainComponent,
    UpdateQpComponent,
    ViewLogsComponent,
    PastArtifactsComponent,
    ExportComponent,
    GenerateComponent
    //UpdatePasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,FormsModule,
    Ng2PaginationModule
  ],
  providers: [AuthGuard,ViewDomainService,ExportService,ViewLogService,PastArtifactsService,generateService,updateqpService,ledgerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
