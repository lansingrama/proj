import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
import { updateqpService } from './update-qp.service'
@Component({
  selector: 'app-update-qp',
  templateUrl: './update-qp.component.html',
  styleUrls: ['./update-qp.component.css']
})
export class UpdateQpComponent implements OnInit {

  constructor(private service: updateqpService, private formBuilder: FormBuilder) { }
  domainObj: any;
  UForm: FormGroup;
  Successmessage: String;
  errorMsg: String;
  ngOnInit() {
    this.errorMsg = null;
    this.domainObj = null;
    this.UForm = this.formBuilder.group({
      path: ['', [Validators.required]],
      content: ['', [Validators.required]]
    })
  }
  updateqp() {
  
    this.service.updateqp(this.UForm.value).subscribe((response) => {
      this.domainObj = response;
     

    }, (err) => { this.errorMsg = err.error.message; })
  }
}