import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { enableBindings } from '../../../node_modules/@angular/core/src/render3';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {
  LForm: FormGroup;

  adminmessage: string;
  errormessage: string;
  usermessage: string;
  returnUrl: string;

  constructor(private router: Router, private loginService: LoginService, private formBuilder: FormBuilder) 
  { }

  ngOnInit() {

    //sessionStorage.setItem('isLoggedIn', "false");
    this.LForm = this.formBuilder.group({
      uname: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9_]+$/)]],
      pword: ['', [Validators.required]],
      
    })
    
    }
  get f() { return this.LForm.controls; }
  
  onFormSubmit() {

    if (this.LForm.invalid) {
      return;
    }
    else {
      this.adminmessage = ""
      this.usermessage = ""

      //this.returnUrl="http://localhost:4200/ledger"
      this.loginService.login(this.LForm.value).subscribe(


        (good) => {
         
         
          if (good.message == "Admin") {
          
           
            sessionStorage.setItem('isLoggedIn', "true");
            sessionStorage.setItem('token', this.f.uname.value);
            sessionStorage.setItem('designation', good.message);
            this.LForm.reset()
            this.router.navigate(['/navbar']);


            // this.adminmessage=good.message
          }
          else if (good.message == "User") {
          
            this.usermessage = good.message
            sessionStorage.setItem('isLoggedIn', "true");
            sessionStorage.setItem('token', this.f.uname.value);
            sessionStorage.setItem('designation', good.message);
            this.LForm.reset()
            this.router.navigate(['/navbar']);
          }
        },
        (bad) => {
          
          this.errormessage = bad.error.message
        }


      );
    }

  }
    variable()
  {
    if(sessionStorage.getItem('isLoggedIn') == "false"){
      return true;
    }
  }
  login:boolean=true;
  
  logout:boolean=true;
  
  click(){
    this.login=false;
    sessionStorage.setItem('isLoggedIn', "false");
    this.router.navigate(['/login']);
  }
   
    clickout(){
      sessionStorage.setItem('isLoggedIn', "false");
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('designation');
      this.logout=false;
      
      this.router.navigate(['/login']);
     }
     login_enable(){
      
      if(sessionStorage.getItem('isLoggedIn') == "false"){
        return true;
      }
      return false;
     }
     
     logout_enable(){
     
      if(sessionStorage.getItem('isLoggedIn') == "true"){
        return true;
      }
      else{
      return false;
      }
     }
     admin()
     {
      if(sessionStorage.getItem('designation') == "Admin"){
       return true;
     
     }
     }
     user()
     {
      if(sessionStorage.getItem('designation') == "User"){
       return true;
     
     }
     }

  }
 






//,Validators.pattern(/(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}/)]