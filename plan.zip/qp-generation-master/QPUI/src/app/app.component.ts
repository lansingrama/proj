import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { checkAndUpdateElementInline } from '../../node_modules/@angular/core/src/view/element';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  bookOptionSelected: boolean = false;
  agree: boolean = false;
  dable: boolean = false;
  visible:boolean;
  constructor(private router: Router) { }
  ngOnInit() {
 // sessionStorage.setItem('isLoggedIn', "false");
  }

   
}