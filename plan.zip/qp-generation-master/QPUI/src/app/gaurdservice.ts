import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
//import { AuthService } from './auth.service';
@Injectable()
export class AuthGuardService implements CanActivate {
  constructor( public router: Router) {}
  canActivate(): boolean {
    if (this.canLoginToday()) {
        console.log("false")
      //this.router.navigate(['login']);
      return true;
    }
    return false;
  }

canLoginToday(): boolean {
    let today = new Date();
    console.log("method inside")
    if(today.getDay()==6 || today.getDay()==5) {
        return false; // weekends
    }
    else {
        console.log("trueeeee")
        return true;
    }
  }
}