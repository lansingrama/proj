import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PastArtifactsComponent } from './past-artifacts.component';

describe('PastArtifactsComponent', () => {
  let component: PastArtifactsComponent;
  let fixture: ComponentFixture<PastArtifactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PastArtifactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastArtifactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
