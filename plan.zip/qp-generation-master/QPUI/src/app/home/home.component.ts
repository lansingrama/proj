import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
//   template: `
//   <img src="">
// `
// template: `<nav class="navbar">

//       <!-- logo -->
//       <div class="navbar-brand">
//         <a class="navbar-item">
//           <img src="./QPUI/src/assets/1.jpg">
//         </a>
//       </div>
//     </nav>`
})

export class HomeComponent implements OnInit {
  

  constructor(private router: Router) { }
  agree: boolean = false;
  dable: boolean = false;
  visible:boolean;
  ngOnInit() {
  }
  login:boolean=true;
  
  logout:boolean=true;
  
  click(){
    
    sessionStorage.setItem('isLoggedIn', "false");
   
    this.login=false;
    this.router.navigate(['/login']);
  }

    clickout(){
      sessionStorage.setItem('isLoggedIn', "false");
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('designation');
      this.logout=false;
      
      this.router.navigate(['/login']);
     }
     login_enable(){
      
      if(sessionStorage.getItem('isLoggedIn') == "false"){
        return true;
      }
      return false;
     }
     
     logout_enable(){
     
      if(sessionStorage.getItem('isLoggedIn') == "true"){
        return true;
      }
      else{
      return false;
      }
     }
     admin()
     {
      if(sessionStorage.getItem('designation') == "Admin"){
       return true;
     
     }
     }
     user()
     {
      if(sessionStorage.getItem('designation') == "User"){
       return true;
     
     }
     }
}
