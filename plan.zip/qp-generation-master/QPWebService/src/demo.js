const path = require('path');
dirpath = "C:\Users\venkataraman.trn\Desktop\New folder"
var mypath = String.raw(dirpath)
console.log(mypath);
var revpath = mypath.replace(/\\/g,"/");
console.log(revpath);


// var dir = require('node-dir');
// var fs = require('fs');
// var request = require('request');

// var PAYLOAD = {
//     "branch": "master",
//     "commit_message": "Posting JSON PayLoad",
//     "actions": []
// }

// var direct = __dirname;
// var files = dir.files(direct, { sync: true });

// for (i = 0; i < files.length; i++) {
//     PAYLOAD.actions[i] = PAYLOAD.actions[i] || {};
//     PAYLOAD.actions[i].action = "create";
//     PAYLOAD.actions[i].file_path = files[i];
//     PAYLOAD.actions[i].content = fs.readFileSync(files[i], "utf8");
// }
// console.log(files);

// // var url = 'http://infygit.ad.infosys.com/api/v4/projects/21571/repository/commits?private_token=TnKiYzQDaZNiFyjd37bP'
// // var options = {
// //     method: 'post',
// //     body: PAYLOAD,
// //     json: true,
// //     url: url
// // }

// // request(options, function (err, res, body) {
// //     if (err) {
// //         console.error('error posting json: ', err)
// //         throw err
// //     }
// //     var headers = res.headers
// //     var statusCode = res.statusCode
// //     console.log('headers: ', headers)
// //     console.log('statusCode: ', statusCode)
// //     console.log('body: ', body)
// // })

// // qps=[1,2,3];
// // qps.splice(0,qps.length-2)
// // console.log(qps);

// // qps = ["IND", "AUS", "PAK","IND","SRI"]
// // bqps = ["AUS", "IND"]
// // qps = qps.filter((el) => {
// //     return bqps.indexOf(el) < 0;
// // });
// // console.log(qps)