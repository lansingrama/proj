const { Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
Mongoose.set('useCreateIndex', true)
var url = "mongodb://localhost:27017/QP_DB";


var loginSchema = Schema({
    userName: String,
    password: String,
    role: String,
    lastLogin: Date
}, { collection: "Users" });



const ledgerSchema = Schema({
    domain: String,
    qpId: String,
    gitLink: String,
    focusArea: String,
    technology: String,
    lastUsed: Date,
    batch: [
        {
            name: String,
            assessmentDate: String
        }
    ],
    author: String
}, { collection: "Ledger" });

var collection = {};

collection.getLogin = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('User', loginSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getLedger = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Ledger', ledgerSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}


module.exports = collection;
