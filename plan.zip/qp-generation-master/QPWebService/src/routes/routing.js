const express = require('express');
const routing = express.Router();
var create = require('../model/dbsetup');
const service = require('../service/users');
const Update = require('../model/update');
const Login = require('../model/login');
const UpdateContent = require('../model/updateContent')
const parser = require('../parser').reportGenerator

var fs = require('fs');

routing.get('/login/:name', function (req, res, next) {
    var name = (req.params.name)
  
    service.getUser(name).then((obj) => {
        
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.get('/domain/:name', function (req, res, next) {
    var name = (req.params.name)
   
    service.getDomain(name).then((obj) => {
        
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.get('/viewdomain', function (req, res, next) {
    service.viewdomain().then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})
routing.get('/pastartifacts', function (req, res, next) {
    service.pastartifacts().then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.get('/generateqp/:batchname/:fa', function (req, res, next) {
    var batchname = (req.params.batchname)
    var fa = (req.params.fa)
   
    service.gQP(batchname, fa).then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.get('/oqp/:batchname/:fa', function (req, res, next) {
    var batchname = (req.params.batchname)
    var fa = (req.params.fa)
    
    service.oQP(batchname, fa).then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.post('/updateqp', function (req, res, next) {
    const uc = new UpdateContent(req.body);
  
    
    service.gitup(uc).then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.get('/export', function (req, res, next) {
    service.export(``).then((obj) => {
        res.json(obj)
    }).catch(function (err) {
        next(err)
    })
})

routing.post('/login', (req, res, next) => {
    const login = new Login(req.body);

    service.login(login).then((result) => {
    
        //return result
        res.json({ "message": result.message });
    }).catch((err) => next(err)
    )
})

routing.get('/view-logs', (req, res, next) => {
    fs.readFile('RequestLogger.txt', function readFileCallback(err, data) {
        if (err) {
            return err
        }
        else {
            let Parser = require('text2json').Parser
            let rawdata = data
            //console.log(rawdata.toString())

            let parse = new Parser({ hasHeader: false })

            parse.text2json(rawdata, (err, data) => {

                res.json(data.reverse())
            })
        }
    })
})


routing.post('/update', (req, res, next) => {
    const update = new Update(req.body);
    service.update(update).then((result) => {
        if (result != null) {
            res.json({ "message": "Password Updated successfully." });
        }
        else {
            res.json({ "message": "Password Update failed,retry later." })
        }
    }).catch((err) => next(err)
    )
})

module.exports = routing;
