class Update {
    constructor(obj) {
        this.userName = obj.userName;
        this.oldPassword = obj.oldPassword;
        this.newPassword = obj.newPassword;
    }
}

module.exports = Update;