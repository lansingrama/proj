class UpdateContent {
    constructor(obj) {
        this.path = obj.path;
        this.content = obj.content;
    }
}

module.exports = UpdateContent;