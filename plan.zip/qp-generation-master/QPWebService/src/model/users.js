var connection = require('../utilities/connection');

var qpDb = {}
//use strict

qpDb.loginDetails = (name) => {
    return connection.getLogin().then((collection) => {
        return collection.findOne({ userName: name }).then((loginData) => {
            if (loginData) {
                return loginData
            }

            else return null
        })
    })
}


qpDb.login = (login) => {
   
    return connection.getLogin().then((collection) => {
        return collection.findOne({ userName: login.userName.toLowerCase() }).then((loginData) => {
            if (!loginData) {
                return null
            }
            else {
                if (loginData.password == login.password) {
                    return collection.updateOne({ userName: login.userName.toLowerCase() }, { $set: { lastLogin: login.lastLogin } })
                        .then((updatedData) => {
                            if (updatedData) {
                                return loginData
                            }
                            else return null
                        })
                }
                else return null
            }
        })
    })
}

qpDb.domainDetails = (domain) => {
    return connection.getLedger().then((collection) => {
        return collection.find({ domain: domain }).then((domainData) => {
            if (domainData) return domainData
            else return null
        })
    })
}

qpDb.viewdomain = () => {
    return connection.getLedger().then((collection) => {
        return collection.aggregate([
            { $sort: { "lastUsed": -1 } }
        ]).then((sortedData) => {
            return sortedData;
        })
    })
}




qpDb.exportDetails = () => {
    return connection.getLedger().then((collection) => {
        return collection.aggregate([
            { $sort: { "lastUsed": -1 } }
        ]).then((sortedData) => {
            return sortedData;
        })
    })
}


qpDb.gQP = (batchname, fa) => {
    return connection.getLedger().then((collection) => {
        return collection.aggregate([
            { $match: { "focusArea": fa } },
            { $sort: { "lastUsed": 1 } }
        ])
            .then((sortedData) => {
                let qps = []                 //holds all qpids of the particular FA 
                let bqps = []               //holds all qpids for the batchname passed to the function

                for (let i of sortedData) {
                    qps.push(i.qpId)
                    for (let j of i.batch) {
                        if (j.name == batchname) {
                            bqps.push(i.qpId)
                        }
                    }
                }
                bqps.splice(0, bqps.length - 2);  //now bqps holds the qpids of the last 2 qp alone 
                qps = qps.filter((el) => {
                    return bqps.indexOf(el) < 0;
                });
               
                var rand = qps[Math.floor(Math.random() * qps.length)];
                qpDb.updateDate(rand, batchname, fa);
                
                return rand;
            })
    })
}

qpDb.oQP = (batchname, fa) => {
    return connection.getLedger().then((collection) => {
        return collection.aggregate([
            { $match: { "focusArea": fa } }
        ])
            .then((sortedData) => {
                let qps = []               //holds all qpids for the batchname passed to the function

                for (let i of sortedData) {
                    qps.push(i.qpId)
                }
                var rand = qps[Math.floor(Math.random() * qps.length)];
                qpDb.updateDate(rand, batchname, fa);
                return rand;
            })
    })
}

qpDb.updateDate = (qpId, bname, fa) => {
    return connection.getLedger().then((collection) => {
        return collection.findOne({ qpId: qpId }).then((qpData) => {
            if (qpData) {
                return collection.updateOne({ qpId: qpId }, {
                    $set: { lastUsed: new Date() },
                    $push: {
                        batch: {
                            $each: [{ name: bname + " " + fa, assessmentDate: new Date() }],
                            $sort: { assessmentDate: -1 }
                        }
                    }
                })
                    .then((updatedData) => {
                        if (updatedData) {
                            
                        }
                    })
            }
        })
    })

}

qpDb.update = (login) => {
    return connection.getLogin().then((collection) => {
        return collection.findOne({ userName: login.userName }).then((loginData) => {
            if (loginData) {
                return collection.updateOne({ userName: login.userName }, { $set: { password: login.newPassword } })
                    .then((updatedData) => {
                        if (updatedData) {
                            return updatedData
                            // return {"message:":"Password Updated Successfully"}
                        }
                    })
            }
            else return null
        })
    })
}

module.exports = qpDb;
