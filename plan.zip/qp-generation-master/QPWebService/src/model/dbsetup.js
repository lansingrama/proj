const connection = require('../utilities/connection');
var today = new Date();
var tomorrow = new Date(today.getTime() + (24 * 60 * 60 * 1000));
var dayafter = new Date(tomorrow.getTime() + (24 * 60 * 60 * 1000));
var year = today.getFullYear();
var month = today.getMonth();
var day = today.getDate();


const loginData = [
    {
        "password": "admin",
        "userName": "admin",
        "role": "Admin",
        "lastLogin": ""

    },
    {
        "password": 600002,
        "userName": "admin1",
        "role": "Admin",
        "lastLogin": ""
    },
   {
        "password": "admin",
        "userName": "admin2",
        "role": "User",
        "lastLogin": ""
    }
];

const qpData = [
    {
        "domain": "FBooking",
        "qpId": "ID-101",
        "gitLink": "",
        "focusArea": "FA2",
        "technology": "Angular",
        "lastUsed": today,
        "batch": [
            {
                "name": "Dec",
                "assessmentDate": "03/25/2018"
            }],
        "author": "Likhith Kolayari"
    },
    {
        "domain": "Solar",
        "qpId": "ID-102",
        "gitLink": "",
        "focusArea": "FA1",
        "technology": "Angular",
        "lastUsed": today,
        "batch": [
            {
                "name": "Dec",
                "assessmentDate": "07/25/2019"
            }],
        "author": "Philips"
    },
    {
        "domain": "SolarWaterHeater",
        "qpId": "ID-103",
        "gitLink": "",
        "focusArea": "FA1",
        "technology": "Angular",
        "lastUsed": tomorrow,
        "batch": [
            {
                "name": "Dec",
                "assessmentDate": "03/30/2019"
            }],
        "author": "Lansing Rama"
    }, 
    {
        "domain": "Water",
        "qpId": "ID-105",
        "gitLink": "",
        "focusArea": "FA1",
        "technology": "Angular",
        "lastUsed": tomorrow,
        "batch": [
            {
                "name": "Dec",
                "assessmentDate": "03/27/2019"
            }],
        "author": "GuruMoorthy"
    }
]

exports.setupDb = () => {
    return connection.getLogin().then((myCollection) => {
        return myCollection.deleteMany().then(() => {
            return myCollection.insertMany(loginData).then(() => {
                return connection.getLedger().then((qpDetails) => {
                    return qpDetails.deleteMany().then(() => {
                        return qpDetails.insertMany(qpData).then((data) => {
                            if (data) {
                                return "Insertion Successfull"
                            } else {
                                throw new Error("Insertion failed")
                            }
                        })
                    })
                })
            })
        })
    })
}