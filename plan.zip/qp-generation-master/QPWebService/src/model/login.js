class Login {
    constructor(obj) {
        this.userName = obj.uname;
        this.password = obj.pword;
        this.lastLogin = new Date();
    }
}

module.exports = Login;