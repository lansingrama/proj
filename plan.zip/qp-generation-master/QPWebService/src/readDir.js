var dir = require('node-dir');
var fs = require('fs');
var request = require('request');

var PAYLOAD = {
    "branch": "master",
    "commit_message": "Posting JSON PayLoad",
    "actions": []
}
var path = String.raw`C:\Users\venkataraman.trn\Desktop\New folder`.replace(/\\/g, "/");
var files = dir.files(path, { sync: true });

var len = path.length;
var code = path.split("/");
var lastlen = code[code.length - 1].length;
var temp = len - lastlen;

for (i = 0; i < files.length; i++) {
    PAYLOAD.actions[i] = PAYLOAD.actions[i] || {};
    PAYLOAD.actions[i].action = "create";
    PAYLOAD.actions[i].file_path = (function () {
        var a = files[i].replace(/\\/g, "/");
        var rp = a.substr(temp,a.length)
        return rp;
    })();
    PAYLOAD.actions[i].content = fs.readFileSync(files[i], "utf8");
}

var url = 'http://infygit.ad.infosys.com/api/v4/projects/21571/repository/commits?private_token=TnKiYzQDaZNiFyjd37bP'
var options = {
    method: 'post',
    body: PAYLOAD,
    json: true,
    url: url
}

request(options, function (err, res, body) {
    if (err) {
        console.error('error posting json: ', err)
        throw err
    }
    var headers = res.headers
    var statusCode = res.statusCode
    console.log('headers: ', headers)
    console.log('statusCode: ', statusCode)
    console.log('body: ', body)
})
