const express = require('express');
const bodyParser = require('body-parser');
var create = require("./model/dbsetup")
const router = require('./routes/routing');
const myErrorLogger = require('./utilities/errorlogger');
const myRequestLogger = require('./utilities/requestlogger');
//var create = require('../model/dbsetup');
const cors = require("cors")
const app = express();
app.use(bodyParser.urlencoded({
    extended: true
  }));
app.use(cors())
app.use(bodyParser.json());



app.use(myRequestLogger);
app.use('/', router);
app.use(myErrorLogger);

app.get('/create', (req, res, next) => {
    create.setupDb().then((data) => {
        res.send({ message: data })
    }).catch((err) => {
        next(err)
    })
})
app.listen(1050);
console.log("Server listening in port 1050");


