import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable()
export class generateService{
    url="http://localhost:1050/generateqp/"
    url1="http://localhost:1050/oqp/"
    constructor(private http:HttpClient){}
    generateqp(batchname:any,fa:any):Observable<any>{
       console.log(this.http.get<any>(this.url+batchname+"/"+fa)) 
        return this.http.get<any>(this.url+batchname+"/"+fa);
    }
    generateqp1(batchname:any,fa:any):Observable<any>{
        console.log(this.http.get<any>(this.url1+batchname+"/"+fa)) 
         return this.http.get<any>(this.url1+batchname+"/"+fa);
     }
}