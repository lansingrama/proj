import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup, FormControl } from '@angular/forms';
import { ledgerService } from './ledger.service'
@Component({
  selector: 'app-ledger',
  templateUrl: './ledger.component.html',
  styleUrls: ['./ledger.component.css']
})
export class LedgerComponent implements OnInit {
  LForm: FormGroup
  d: Date
  domainObj: String
  errorMsg: String
  constructor(private formBuilder: FormBuilder, private service: ledgerService) { }

  ngOnInit() {



    this.LForm = this.formBuilder.group({
      directory: ['', [Validators.required]],
    })
  }
  uploadFile(path) {
    // console.log("domain"+domain)
    // console.log("final"+this.final)
    this.service.uploadFile(path).subscribe((response) => {
      this.domainObj = response;
      console.log(this.domainObj)

    }, (err) => { this.errorMsg = err.error.message; })
  }
}




