import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable()
export class ledgerService{
    url="http://localhost:1050/uartifacts/"
    constructor(private http:HttpClient){}
    uploadFile(path:any):Observable<any>{
        console.log(this.http.get<any>(this.url,path)) 
         return this.http.get<any>(this.url,path);
     }
}