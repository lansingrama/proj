import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mailer-template',
  templateUrl: './mailer-template.component.html',
  styleUrls: ['./mailer-template.component.css']
})
export class MailerTemplateComponent implements OnInit {
  LForm: FormGroup;
  constructor(private router: Router, private formBuilder: FormBuilder) { }
  

  // isPopupVisible:boolean
  // isComposePopupVisible:boolean
  // composeEmail:any
  // activeTab:string
  // sentEmails :any
  // selectedEmail:string
  ngOnInit() {
    this.LForm = this.formBuilder.group({
      to: ['', Validators.required],
      subject: [''],
      text:[ '',Validators.required]
      



    })
    
  }
// Full blog post at: http://www.simplygoodcode.com/2013/12/how-to-make-email-web-app-using-angular.html

 // Full blog post at: http://www.simplygoodcode.com/2013/12/how-to-make-email-web-app-using-angular.html

//   EmailController() {
//     console.log("ajsdfaghfj");
//   this.isPopupVisible = false;
//   this.isComposePopupVisible = false;
//   this.composeEmail = {};
//   this.activeTab = "inbox";
//   this.sentEmails = [];
//   }
//   sendEmail() {
//       this.isComposePopupVisible = false;
//       this.composeEmail.from = "me";
//       this.composeEmail.date = new Date();        
//       this.sentEmails.push(this.composeEmail);
//   };
  
//   showComposePopup() {
//       this.composeEmail = {};
//       this.isComposePopupVisible = true;
//   };
  
//   closeComposePopup() {
//     this.isComposePopupVisible = false;
//   };
  
//   showPopup(email) {
//     this.isPopupVisible = true;
//     this.selectedEmail = email;
//   };
  
//   closePopup() {
//     this.isPopupVisible = false;
//   };
  
//   emails = [
//       { 
//           from: 'John',
//           to: 'me',
//          subject: 'I love angular', 
//           date: 'Jan 1', 
//           body: 'hello world!' 
//       },
//       { 
//           from: 'Jack', 
//           to: 'me',
//           subject: 'Angular and I are just friends', 
//           date: 'Feb 15', 
//           body: 'just kidding' 
//       },
//       { 
//           from: 'Ember', 
//           to: 'me',
//           subject: 'I hate you Angular!', 
//           date: 'Dec 8', 
//           body: 'wassup dude' 
//       }
//   ];
 }
