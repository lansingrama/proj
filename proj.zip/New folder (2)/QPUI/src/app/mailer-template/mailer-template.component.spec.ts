import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MailerTemplateComponent } from './mailer-template.component';

describe('MailerTemplateComponent', () => {
  let component: MailerTemplateComponent;
  let fixture: ComponentFixture<MailerTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MailerTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MailerTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
