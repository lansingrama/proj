import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQpComponent } from './update-qp.component';

describe('UpdateQpComponent', () => {
  let component: UpdateQpComponent;
  let fixture: ComponentFixture<UpdateQpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateQpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
