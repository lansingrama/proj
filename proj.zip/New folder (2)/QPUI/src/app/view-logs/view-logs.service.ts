import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
//import { AccessGuard } from '../gaurdservice';

@Injectable()
export class ViewLogService {

 //add neccessary dependencies\
 

  constructor(public http: HttpClient) {
   
  }
  viewlogs() : Observable<any> {
    //  console.log("hello form service")
    return <Observable<any>> this.http.get(`http://localhost:1050/view-logs`);
  }
  
    
 
}
