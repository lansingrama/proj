string1=[
    {
        "name": "Dec",
        "assessmentDate": "03/25/2019"
    }]
console.log(string1[0].length);
