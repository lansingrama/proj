import { Component, OnInit } from '@angular/core';
import { ExportService } from './export.service';
@Component({
  selector: 'app-export',
  templateUrl: './export.component.html',
  styleUrls: ['./export.component.css']
})

export class ExportComponent implements OnInit {

  constructor(public service: ExportService) {
    console.log(" Constructor Intialised")
  }
  domainObj: any;
  errorMsg: String;
  detailsObj: String;
  element: String;
  ngOnInit() {
    console.log("Intialised")
    this.errorMsg = null;
    this.domainObj = null;
    this.service.export().subscribe((response) => {
      this.domainObj = response;
      //  this.token=sessionStorage.getItem('token')
      //console.log("tokennnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn")
      console.log("exporttttttttttttttttttpageeeeeeeeeeee")
      console.log(this.domainObj)

    }, (err) => { this.errorMsg = err.error.message; })
  }


  download() {
    this.service.export().subscribe((good) => {
      // console.log("guuuuuuuuuuddddddddddd")
      // console.log(good)
      // console.log(Object.keys(good[0]))
      let data = good
      // console.log("dataaaaaaaaaaaaaaaaaa"+data.domain)
      // let a=String(0)
      // let b=a.domain
      //  console.log(good.domain)
      // console.log("dataaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"+Object.keys(data))
      // this.successmessage = good

      let csvHeader = ["Domain","QPID","Gitlink","FocusArea","Technology","Lastused","BatchName","AssessmentDate","Author"]
      // let csvHeader1 = []
      // csvHeader = Object.keys(data[0]);
      // csvHeader1=Object.keys(data[0].batch[0])
      // csvHeader=csvHeader.push(data[0])
      // console.log("sdadasd"+csvHeader)
      // console.log("1111111111111111111111111111111111" + csvHeader1)
      //  console.log(csvHeader)
      let csvData = this.ConvertToCSV(data, csvHeader);
      let blob = new Blob([csvData], { type: 'text/csv' });
      let dwldLink = document.createElement("a");
      let url = window.URL.createObjectURL(blob);
      let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
      if (isSafariBrowser) { //if Safari open in new window to save file with random filename.
        dwldLink.setAttribute("target", "_blank");
      }
      dwldLink.setAttribute("href", url);
      dwldLink.setAttribute("download", "Domain.csv");
      dwldLink.style.visibility = "hidden";
      document.body.appendChild(dwldLink);
      dwldLink.click();
      document.body.removeChild(dwldLink);
    },
      error => {
        let err = JSON.parse(error._body);
        // this.service.export('error', err.message);
      }
    );
  }
  ConvertToCSV(objArray, headerList) {
    //console.log('convert to array called');
    //console.log("headdddddddddd ")
    //console.log(headerList)
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;

    var str = '';
    var row = 'S.No,';
    //console.log(headerList[3])

    for (var index in headerList) { //objArray[0]
      //Now convert each value to string and comma-separated
      console.log(index)
      row += headerList[index] + ',';
      console.log(row)

    }
    row = row.slice(0, -1);

    //append Label row with line break
    str += row + '\r\n';

    for (var i = 0; i < 1; i++) {
      var count = 1

      var line = '';

      for (var index in objArray) {//array[i]

        //   let head = headerList[index];

        line += count
        line += ',' + array[index].domain;
        line += ',' + array[index].qpId;
        line += ',' + array[index].gitLink;
        line += ',' + array[index].focusArea;
        line += ',' + array[index].technology;
        line += ',' + array[index].lastUsed;
        line += ',' + array[index].batch[0].name;
        line += ',' + array[index].batch[0].assessmentDate;
        line += ',' + array[index].author;
        line += '\n'
        count++;

      }
      str += line + '\r\n';

    }
    return str;
  }

}

