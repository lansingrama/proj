import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { checkAndUpdateElementInline } from '../../node_modules/@angular/core/src/view/element';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  bookOptionSelected: boolean = false;
  agree: boolean = false;
  dable: boolean = false;
  visible:boolean;
  constructor(private router: Router) { }
  ngOnInit() {
 // sessionStorage.setItem('isLoggedIn', "false");
  }
//   login:boolean=true;
  
// logout:boolean=true;

// click(){
//   this.login=false;
//   sessionStorage.setItem('isLoggedIn', "false");
//   this.router.navigate(['/login']);
// }
//   // selected() {
//   //   this.bookOptionSelected = true;
//   //   this.dable=false;
//   //   this.router.navigate(['/book']  );
//   // }

//   // agreed(val) {
//   //   if (val == 1) {
//   //     this.agree = true;
//   //     this.router.navigate(['/login']);
//   //   }
//   //   else if (val == 2) {
//   //     this.agree = true;
//   //     this.router.navigate(['/view']);
//   //   }
//   //   else if (val == 3) {
//   //     this.agree = true;
//   //     this.router.navigate(['/verify'])
//   //   }
//   //   else if (val == 4) {
//   //     this.agree = true;
//   //     this.router.navigate(['/ledger'])
//   //   }
    
//   // }
//   clickout(){
//     sessionStorage.setItem('isLoggedIn', "false");
//     sessionStorage.removeItem('token');
//     sessionStorage.removeItem('designation');
//     this.logout=false;
    
//     this.router.navigate(['/login']);
//    }
//    login_enable(){
    
//     if(sessionStorage.getItem('isLoggedIn') == "false"){
//       return true;
//     }
//     return false;
//    }
   
//    logout_enable(){
   
//     if(sessionStorage.getItem('isLoggedIn') == "true"){
//       return true;
//     }
//     else{
//     return false;
//     }
//    }
//    admin()
//    {
//     if(sessionStorage.getItem('designation') == "Admin"){
//      return true;
   
//    }
//    }
//    user()
//    {
//     if(sessionStorage.getItem('designation') == "User"){
//      return true;
   
//    }
//    }
   
}