import { Component, OnInit } from '@angular/core';
import { ViewDomainService } from './view-domain.service';
@Component({
  selector: 'app-view-domain',
  templateUrl: './view-domain.component.html',
  styleUrls: ['./view-domain.component.css']
})
export class ViewDomainComponent implements OnInit {

  constructor(public service: ViewDomainService) { }
  domainObj: any;
  errorMsg: String;
  detailsObj: String;
  element: String;
  final:String;
  ngOnInit() {
    this.errorMsg = null;
    this.domainObj = null;
    this.service.viewdomain().subscribe((response) => {
      this.domainObj = response;
      console.log(this.domainObj)
      
    }, (err) => { this.errorMsg = err.error.message; })
    
  }


viewdetails(domain){
  console.log("domain"+domain)
  for(let element of this.domainObj){
    if(element.domain==domain){
      this.final=element
    }
  }
  console.log("final"+this.final)
  
}  // flag: boolean = true;

}

