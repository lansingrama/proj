import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable()
export class LoginService{
    url="http://localhost:1050/login"
    constructor(private http:HttpClient){}
    login(data:any):Observable<any>{
       console.log(this.http.post<any>(this.url,data)) 
        return this.http.post<any>(this.url,data);
    }
}