import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { enableBindings } from '../../../node_modules/@angular/core/src/render3';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {
  LForm: FormGroup;

  adminmessage: string;
  errormessage: string;
  usermessage: string;
  returnUrl: string;

  constructor(private router: Router, private loginService: LoginService, private formBuilder: FormBuilder) 
  { }

  ngOnInit() {

    //sessionStorage.setItem('isLoggedIn', "false");
    this.LForm = this.formBuilder.group({
      uname: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9_]+$/)]],
      pword: ['', [Validators.required]],
      
    })
    
    }
  get f() { return this.LForm.controls; }
  
  onFormSubmit() {

    if (this.LForm.invalid) {
      return;
    }
    else {


      //let uname = this.LForm.get('uname').value;
      //console.log(uname)
      //let pwd = this.LForm.get('pword').value;
      this.adminmessage = ""
      this.usermessage = ""

      //this.returnUrl="http://localhost:4200/ledger"
      this.loginService.login(this.LForm.value).subscribe(


        (good) => {
         
          console.log("hi")
          if (good.message == "Admin") {
          
            console.log("goodadmin" + good.message)
            sessionStorage.setItem('isLoggedIn', "true");
            sessionStorage.setItem('token', this.f.uname.value);
            sessionStorage.setItem('designation', good.message);
            this.LForm.reset()
            this.router.navigate(['/navbar']);


            // this.adminmessage=good.message
          }
          else if (good.message == "User") {
            console.log("gooduser" + good.message)
            this.usermessage = good.message
            sessionStorage.setItem('isLoggedIn', "true");
            sessionStorage.setItem('token', this.f.uname.value);
            sessionStorage.setItem('designation', good.message);
            this.LForm.reset()
            this.router.navigate(['/navbar']);
          }
        },
        (bad) => {
          console.log("bad")
          this.errormessage = bad.error.message
        }


      );
    }

  }
    variable()
  {
    if(sessionStorage.getItem('isLoggedIn') == "false"){
      return true;
    }
  }
  login:boolean=true;
  
  logout:boolean=true;
  
  click(){
    this.login=false;
    sessionStorage.setItem('isLoggedIn', "false");
    this.router.navigate(['/login']);
  }
    // selected() {
    //   this.bookOptionSelected = true;
    //   this.dable=false;
    //   this.router.navigate(['/book']  );
    // }
  
    // agreed(val) {
    //   if (val == 1) {
    //     this.agree = true;
    //     this.router.navigate(['/login']);
    //   }
    //   else if (val == 2) {
    //     this.agree = true;
    //     this.router.navigate(['/view']);
    //   }
    //   else if (val == 3) {
    //     this.agree = true;
    //     this.router.navigate(['/verify'])
    //   }
    //   else if (val == 4) {
    //     this.agree = true;
    //     this.router.navigate(['/ledger'])
    //   }
      
    // }
    clickout(){
      sessionStorage.setItem('isLoggedIn', "false");
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('designation');
      this.logout=false;
      
      this.router.navigate(['/login']);
     }
     login_enable(){
      
      if(sessionStorage.getItem('isLoggedIn') == "false"){
        return true;
      }
      return false;
     }
     
     logout_enable(){
     
      if(sessionStorage.getItem('isLoggedIn') == "true"){
        return true;
      }
      else{
      return false;
      }
     }
     admin()
     {
      if(sessionStorage.getItem('designation') == "Admin"){
       return true;
     
     }
     }
     user()
     {
      if(sessionStorage.getItem('designation') == "User"){
       return true;
     
     }
     }

  }
 






//,Validators.pattern(/(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}/)]