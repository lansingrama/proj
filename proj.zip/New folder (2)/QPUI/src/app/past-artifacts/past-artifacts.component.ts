import { Component, OnInit } from '@angular/core';
import { PastArtifactsService } from './past-artifacts.service'

@Component({
  selector: 'app-past-artifacts',
  templateUrl: './past-artifacts.component.html',
  styleUrls: ['./past-artifacts.component.css']
})
export class PastArtifactsComponent implements OnInit {

  constructor(public service:PastArtifactsService) { }
  domainObj: any;
  errorMsg: String;
  detailsObj: String;
  element: String;
  final:String;

  ngOnInit() {
    this.errorMsg = null;
    this.domainObj = null;
    this.service.viewartifacts().subscribe((response) => {
      this.domainObj = response;
      console.log(this.domainObj)
      
    }, (err) => { this.errorMsg = err.error.message; })
    
  }

  viewartifacts(domain){
  console.log("domain"+domain)
  for(let element of this.domainObj){
    if(element.domain==domain){
      this.final=element
    }
  }
  console.log("final"+this.final)
  
}

}
