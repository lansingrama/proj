// // const fs = require('fs');
// // let requestlogger=(req,res,next) => {
// // 	fs.appendFile('RequestLogger.txt', new Date() + ' ' + req.method  + ' ' +  req.url  +  "\n" , (err) => {
// // 	  if (err) {
// // 				console.log("logging request failed");
// // 			   }
// // 	});			
// //    next();	
// // }
// // module.exports = requestlogger;

// var fs = require('fs');

// var requestLogger = function (req, res, next) {
//     var obj = []
//     // //     console.log("b0000000000000000o"+req.body.uname)
//     var logMessage = {
//         Date: new Date(),
//         Method: req.method,
//         Url: req.url,
//         UserName: req.body.uname
//     };
   
//     //var obj = '{"table": [{"teamId":"1","status":"pending"}]}';
//  //   fs.exists('RequestLogger.json', function (exists) {
//         // if(exists){
//         //     console.log("yes file exists");
//          fs.readFile('RequestLogger.json', function readFileCallback(err, data) {
//              if (err) {
//                  console.log(err);
//              } else {
//                  console.log("yesssssssssssssssssssssssssssssssssss")
//                  var datas = JSON.parse(data);
//                  console.log("datasssssssssssssssssssssssssssss "+datas)

//                  obj.push(logMessage);


//                 obj = JSON.stringify(obj)
//                   console.log(obj)
//                 fs.appendFile('RequestLogger.json', obj, (err) => {
//                     if (err) {
//                         console.log("caaloooooooo back eerrroor")
//                     }
//                 });
//             }
        
// //             }
//        })

// //     })
//  }

// else {
//             console.log("file not exists")

//             obj['table'].push(logMessage);
//        obj=JSON.stringify(datas)
//        fs.writeFile('RequestLogger.json', json,(err)=>{
//         			if(err){
//         				console.log("caaloooooooo back eerrroor")
//         			}
//         		}); 
//             }
// })    
// }
// fs.exists('RequestLogger.json', function(exists){
//     if(exists){
//         console.log("yes file exists");
//         fs.readFile('RequestLogger.json', function readFileCallback(err, data){
//         if (err){
//             console.log(err);
//         } else {
//         obj = JSON.parse(data); 

//         obj.table.push(logMessage);

//         var json = JSON.stringify(obj); 
//         fs.writeFile('RequestLogger.json', json,(err)=>{
// 			if(err){
// 				console.log("caaloooooooo back eerrroor")
// 			}
// 		}); 
//         }});
//     } else {
//         console.log("file not exists")

//         obj.table.push(logMessage);

//         var json = JSON.stringify(obj);
//         fs.writeFile('RequestLogger.json', json,(err)=>{
// 			if(err){
// 				console.log("caal back eerrroor")
// 			}
// 		});
//         }
// 	});
// }
//module.exports = requestLogger;









//mainnnnnnn

 const fs = require('fs');
 var user1;
let requestlogger=(req,res,next) => {
	//const data=sessionStorage.getItem('token')
	let date=new Date();
	let method=req.method;
	let url=req.url;
	
	if(url=='/login')
	{
		var user=req.body.uname;
		user1=user;
	
fs.appendFile('RequestLogger.txt', new Date() + ',' + req.method  + ',' +  req.url  + ','+user+"\n" , (err) => {
	  if (err) {
 				console.log("logging request failed");
 			   }
});			
    next();	
}

else{
	//var user1=user
	fs.appendFile('RequestLogger.txt', new Date() + ',' + req.method  + ',' +  req.url  + ','+user1+"\n" , (err) => {
		if (err) {
				   console.log("logging request failed");
				  }
  });			
	  next();	

}
}
module.exports=requestlogger;



















// const fs = require('fs');
// let requestlogger=(req,res,next) => {
// 	fs.appendFile('RequestLogger.txt', new Date() + ' ' + req.method  + ' ' +  req.url  +  "\n" , (err) => {
// 	  if (err) {
// 				console.log("logging request failed");
// 			   }
// 	});			
//    next();	
// }
// module.exports = requestlogger;

// var fs = require('fs');

// var requestLogger = function (req, res, next) {
// 	// //     console.log("b0000000000000000o"+req.body.uname)
// 	var logMessage = {
// 		Date: new Date(),
// 		Method: req.method,
// 		Url: req.url,
// 		UserName: req.body.uname
//     }
//     //var obj =[{}];



// 	// fs.readFile('RequestLogger.json', function readFileCallback(err, data){
//     //     if (err){
//     //         console.log(err);
//     //     } else {
//        // obj = JSON.parse(JSON.stringify(data)); 
//        // console.log("objjjjjjjjjjjjjjjjj"+obj)
//        console.log("loggggggggggggggggg"+logMessage.Date)

//      //   jsons.push(obj);
//     // var element=JSON.parse(logMessage);

//      fs.readFile('RequestLogger.json', function readFileCallback(err, data){
//          console.log("readingggggggggggggggg")

//          //=JSON.parse(data);
//       //   array.push(data);
//       //var array=[];
//          var array=[];
//          array.push(logMessage);
//          console.log("readdataaaaaaaaaaaaaaaa"+array)

//         //var hi = JSON.parse(JSON.stringify(logMessage)); 
//        // jsons.push(hi)
//         fs.appendFile('RequestLogger.json',  JSON.stringify(array),(err)=>{
// 			if(err){
// 				console.log("caaloooooooo back eerrroor")
//             }
//             console.log("writtttttttttteeeeeeeeeennnnnnnnnn")
// 		}); 
//    //     }
//     });
// }


// fs.exists('RequestLogger.json', function(exists){
//     if(exists){
//         console.log("yes file exists");
//         fs.readFile('RequestLogger.json', function readFileCallback(err, data){
//         if (err){
//             console.log(err);
//         } else {
//         obj = JSON.parse(data); 

//         obj.table.push(logMessage);

//         var json = JSON.stringify(obj); 
//         fs.writeFile('RequestLogger.json', json,(err)=>{
// 			if(err){
// 				console.log("caaloooooooo back eerrroor")
// 			}
// 		}); 
//         }});
//     } else {
//         console.log("file not exists")

//         obj.table.push(logMessage);

//         var json = JSON.stringify(obj);
//         fs.writeFile('RequestLogger.json', json,(err)=>{
// 			if(err){
// 				console.log("caal back eerrroor")
// 			}
// 		});
//         }
// 	});

//	module.exports = requestLogger;











//  const fs = require('fs');
// let requestlogger=(req,res,next) => {
// fs.appendFile('RequestLogger.txt', new Date() + ' ' + req.method  + ' ' +  req.url  + ' '+req.body.uname+ "\n" , (err) => {
// 	  if (err) {
//  				console.log("logging request failed");
//  			   }
// });			
//     next();	
// }
// module.exports=requestlogger 