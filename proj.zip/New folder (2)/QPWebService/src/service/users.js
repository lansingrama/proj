var model = require('../model/users');
var request = require('request');

var qpService = {}

qpService.gitup = (uc) => {
    var PAYLOAD = {
        "branch": "master",
        "commit_message": "Update",
        "actions": [
            {
                "action": "update",
                "file_path": uc.path,
                "content": uc.content
            }
        ]
    }
    var url = 'http://infygit.ad.infosys.com/api/v4/projects/21571/repository/commits?private_token=TnKiYzQDaZNiFyjd37bP'
    var options = {
        method: 'post',
        body: PAYLOAD,
        json: true,
        url: url
    }
    request(options, function (err, res, body) {
        if (err) {
            console.error('error posting json: ', err)
            throw err
        }
        var headers = res.headers
        var statusCode = res.statusCode
        console.log('headers: ', headers)
        console.log('statusCode: ', statusCode)
        console.log('body: ', body)
    })

}
qpService.getUser = (name) => {
    return model.loginDetails(name).then((user) => {
        if (user == null) {
            let err = new Error("User details not found");
            err.status = 404;
            throw err;
        } else {
            return user
        }
    })
}

qpService.getDomain = (name) => {
    return model.domainDetails(name).then((details) => {
        if (details == null) {
            let err = new Error("Domain details not found");
            err.status = 404;
            throw err;
        } else {
            return details
        }
    })
}
qpService.export = () => {
    return model.exportDetails().then((details) => {
        if (details == null) {
            let err = new Error("export details not found");
            err.status = 404;
            throw err;
        } else {
            return details
        }
    })
}

qpService.viewdomain = () => {
    return model.viewdomain().then((details) => {
        if (details == null) {
            let err = new Error("Domain details not found");
            err.status = 404;
            throw err;
        } else {
            console.log(details);

            return details
        }
    })
}

qpService.pastartifacts = () => {
    return model.viewdomain().then((details) => {
        if (details == null) {
            let err = new Error("Domain details not found");
            err.status = 404;
            throw err;
        } else {
            console.log(details);
            return details
        }
    })
}

qpService.gQP = (batchname, fa) => {
    console.log("hello service")
    return model.gQP(batchname, fa).then((details) => {
        console.log(details);
        
        if (details == null) {
            let err = new Error("QP Not available");
            err.status = 404;
            throw err;
        }
        else return details;
    })
}

qpService.oQP = (batchname, fa) => {
    return model.oQP(batchname, fa).then((details) => {
        if (details == null) {
            let err = new Error("QP Not available");
            err.status = 404;
            throw err;
        }
        else return details;
    })
}

// qpService.logs=()=>{
//     return model.logs().then((logdetails)=>{
//         console.log("jiiiiiiiiiiiiiiiiii")
//         if(logdetails){
//             console.log("logggggggggggggggggggggggggggg"+logdetails)
//             return logdetails
//         }
//         else{
//             return null
//         }
//     })
// }
qpService.update = (login) => {
    console.log("logiiiiiiiinnnnnn" + login.oldPassword)
    return model.loginDetails(login.userName).then((user) => {
        console.log("userrrrrrrrrrrrrrrrrrrr" + user)
        if (login.oldPassword == user.password) {
            console.log(login.oldPassword)
            console.log(user.password)
            return model.update(login).then((res) => {
                if (res == null) {
                    let err = new Error("User not found");
                    err.status = 404;
                    throw err;
                } else {
                    return res;
                }

            })
        }
        else {
            console.log("dsadsafdsderrrrrrrrrrrrrrrorrrrrrrrrrrrrrrrrrr")
            return null
        }
    })

}

qpService.login = (login) => {
    return model.login(login).then((user) => {
        //   console.log(user);

        if (user) {
            console.log("UserData" + user)
            console.log("user" + user.role)
            //return user.role
            return { "message": user.role }

        }



        else {
            let err = new Error("Invalid Credentials");
            err.status = 404;
            throw err;
        }
    })
}

module.exports = qpService;