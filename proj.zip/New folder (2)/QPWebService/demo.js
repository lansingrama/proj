const path = require('path');
var dir = `C:\Users\venkataraman.trn\Desktop\New folder`;
var drive = String.raw(dir)
var revpath = drive.replace(/\\/g,"/");
console.log(revpath);
